********************************************************************************************
				Title :	Copy specific type files from source folder/s to destination folder
				Author: Prasad Nayak
				Date  : 11 May 20120
********************************************************************************************

--------------------------------------------------------------------------------------------------------------------------------

Execution:

	1. Extract "Filecopy_src2dst.zip" to a local folder
	2. Open "dist" directory
	3. Run/ double click on "parse.exe", command window opens
	4. Enter file type extension seperated by comma: eg: txt, xls, mp4, pdf, PDF
	4. Enter source path:
	5. Enter destination path:
--------------------------------------------------------------------------------------------------------------------------------